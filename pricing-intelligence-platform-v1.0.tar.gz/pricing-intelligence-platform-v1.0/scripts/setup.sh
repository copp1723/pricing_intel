#!/bin/bash

# Pricing Intelligence Platform Setup Script
# Prepares the system for deployment

set -e

echo "🔧 Setting up Pricing Intelligence Platform"
echo "=========================================="

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Check prerequisites
echo "Checking prerequisites..."
if ! command -v python3.11 &> /dev/null; then
    echo "❌ Python 3.11 is required but not installed"
    exit 1
fi

if ! command -v pnpm &> /dev/null; then
    echo "❌ pnpm is required but not installed"
    echo "Install with: npm install -g pnpm"
    exit 1
fi

echo "✅ Prerequisites check passed"

# Setup backend
echo "Setting up backend..."
cd "$PROJECT_ROOT/backend/pricing-api"

if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3.11 -m venv venv
fi

source venv/bin/activate
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create database directory
mkdir -p src/database

echo "✅ Backend setup completed"

# Setup frontend
echo "Setting up frontend..."
cd "$PROJECT_ROOT/frontend/pricing-dashboard"

echo "Installing Node.js dependencies..."
pnpm install

echo "✅ Frontend setup completed"

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "Next steps:"
echo "1. Run: ./scripts/deploy.sh"
echo "2. Access dashboard at: http://localhost:5173"
echo "3. Access API at: http://localhost:5001"
