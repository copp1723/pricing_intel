"""
Vehicle matching service for finding comparable vehicles
Uses various similarity algorithms and embedding-based matching
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
from src.models.vehicle import db, Vehicle, VehicleMatch
from sqlalchemy import and_, or_, func
import logging
from datetime import datetime
import json
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VehicleSimilarityCalculator:
    """Calculate similarity between vehicles using multiple criteria"""
    
    # Weights for different matching criteria
    WEIGHTS = {
        'year': 0.20,
        'make': 0.25,
        'model': 0.25,
        'trim': 0.15,
        'condition': 0.10,
        'mileage': 0.05
    }
    
    @staticmethod
    def calculate_year_similarity(year1: int, year2: int) -> float:
        """Calculate year similarity (0-1)"""
        if not year1 or not year2:
            return 0.0
        
        year_diff = abs(year1 - year2)
        
        # Exact match
        if year_diff == 0:
            return 1.0
        # Within 1 year
        elif year_diff == 1:
            return 0.8
        # Within 2 years
        elif year_diff == 2:
            return 0.6
        # Within 3 years
        elif year_diff == 3:
            return 0.4
        # Within 5 years
        elif year_diff <= 5:
            return 0.2
        else:
            return 0.0
    
    @staticmethod
    def calculate_string_similarity(str1: str, str2: str) -> float:
        """Calculate string similarity using Jaccard similarity"""
        if not str1 or not str2:
            return 0.0
        
        str1 = str1.upper().strip()
        str2 = str2.upper().strip()
        
        # Exact match
        if str1 == str2:
            return 1.0
        
        # Tokenize and calculate Jaccard similarity
        tokens1 = set(str1.split())
        tokens2 = set(str2.split())
        
        if not tokens1 or not tokens2:
            return 0.0
        
        intersection = len(tokens1.intersection(tokens2))
        union = len(tokens1.union(tokens2))
        
        return intersection / union if union > 0 else 0.0
    
    @staticmethod
    def calculate_mileage_similarity(mileage1: Optional[int], mileage2: Optional[int]) -> float:
        """Calculate mileage similarity (0-1)"""
        if mileage1 is None or mileage2 is None:
            # If both are None (new vehicles), consider similar
            if mileage1 is None and mileage2 is None:
                return 1.0
            return 0.5  # Partial match if one is missing
        
        # Both are zero (new vehicles)
        if mileage1 == 0 and mileage2 == 0:
            return 1.0
        
        # Calculate percentage difference
        max_mileage = max(mileage1, mileage2)
        if max_mileage == 0:
            return 1.0
        
        diff_pct = abs(mileage1 - mileage2) / max_mileage
        
        # Convert to similarity score
        if diff_pct <= 0.1:  # Within 10%
            return 1.0
        elif diff_pct <= 0.2:  # Within 20%
            return 0.8
        elif diff_pct <= 0.3:  # Within 30%
            return 0.6
        elif diff_pct <= 0.5:  # Within 50%
            return 0.4
        else:
            return 0.2
    
    @classmethod
    def calculate_overall_similarity(cls, vehicle1: Vehicle, vehicle2: Vehicle) -> Tuple[float, Dict[str, float]]:
        """
        Calculate overall similarity between two vehicles
        Returns (overall_score, component_scores)
        """
        
        # Calculate individual similarity scores
        year_sim = cls.calculate_year_similarity(vehicle1.year, vehicle2.year)
        make_sim = cls.calculate_string_similarity(vehicle1.make, vehicle2.make)
        model_sim = cls.calculate_string_similarity(vehicle1.model, vehicle2.model)
        trim_sim = cls.calculate_string_similarity(vehicle1.trim or '', vehicle2.trim or '')
        condition_sim = 1.0 if vehicle1.condition == vehicle2.condition else 0.0
        mileage_sim = cls.calculate_mileage_similarity(vehicle1.mileage, vehicle2.mileage)
        
        # Component scores
        component_scores = {
            'year': year_sim,
            'make': make_sim,
            'model': model_sim,
            'trim': trim_sim,
            'condition': condition_sim,
            'mileage': mileage_sim
        }
        
        # Calculate weighted overall score
        overall_score = sum(
            cls.WEIGHTS[component] * score 
            for component, score in component_scores.items()
        )
        
        return overall_score, component_scores

class VehicleMatchingEngine:
    """Main vehicle matching engine"""
    
    def __init__(self):
        self.similarity_calculator = VehicleSimilarityCalculator()
    
    def find_matches(self, target_vehicle: Vehicle, min_similarity: float = 0.3, 
                    max_matches: int = 10, exclude_same_dealer: bool = True) -> List[Dict]:
        """
        Find matching vehicles for a target vehicle
        
        Args:
            target_vehicle: Vehicle to find matches for
            min_similarity: Minimum similarity threshold (0-1)
            max_matches: Maximum number of matches to return
            exclude_same_dealer: Whether to exclude vehicles from same dealer
            
        Returns:
            List of match dictionaries with vehicle and similarity info
        """
        
        logger.info(f"Finding matches for vehicle: {target_vehicle.vin}")
        
        # Build base query
        query = Vehicle.query.filter(Vehicle.id != target_vehicle.id)
        
        # Exclude same dealer if requested
        if exclude_same_dealer:
            query = query.filter(Vehicle.dealer_name != target_vehicle.dealer_name)
        
        # Pre-filter by make and model for performance
        query = query.filter(
            and_(
                Vehicle.make == target_vehicle.make,
                Vehicle.model == target_vehicle.model
            )
        )
        
        # Get candidate vehicles
        candidates = query.all()
        
        logger.info(f"Found {len(candidates)} candidate vehicles for matching")
        
        # Calculate similarities
        matches = []
        for candidate in candidates:
            similarity_score, component_scores = self.similarity_calculator.calculate_overall_similarity(
                target_vehicle, candidate
            )
            
            if similarity_score >= min_similarity:
                match_info = {
                    'vehicle': candidate,
                    'similarity_score': similarity_score,
                    'component_scores': component_scores,
                    'exact_match': similarity_score >= 0.9,
                    'year_match': component_scores['year'] >= 0.8,
                    'make_match': component_scores['make'] >= 0.8,
                    'model_match': component_scores['model'] >= 0.8,
                    'trim_match': component_scores['trim'] >= 0.8,
                    'condition_match': component_scores['condition'] >= 0.8
                }
                matches.append(match_info)
        
        # Sort by similarity score (descending)
        matches.sort(key=lambda x: x['similarity_score'], reverse=True)
        
        # Limit results
        matches = matches[:max_matches]
        
        logger.info(f"Found {len(matches)} matches above threshold {min_similarity}")
        
        return matches
    
    def store_matches(self, target_vehicle: Vehicle, matches: List[Dict]) -> int:
        """
        Store vehicle matches in database
        Returns number of matches stored
        """
        
        # Clear existing matches for this vehicle
        VehicleMatch.query.filter_by(source_vehicle_id=target_vehicle.id).delete()
        
        stored_count = 0
        for match_info in matches:
            match_vehicle = match_info['vehicle']
            
            vehicle_match = VehicleMatch(
                source_vehicle_id=target_vehicle.id,
                match_vehicle_id=match_vehicle.id,
                similarity_score=match_info['similarity_score'],
                exact_match=match_info['exact_match'],
                year_match=match_info['year_match'],
                make_match=match_info['make_match'],
                model_match=match_info['model_match'],
                trim_match=match_info['trim_match'],
                condition_match=match_info['condition_match']
            )
            
            db.session.add(vehicle_match)
            stored_count += 1
        
        db.session.commit()
        
        logger.info(f"Stored {stored_count} matches for vehicle {target_vehicle.vin}")
        return stored_count
    
    def get_stored_matches(self, target_vehicle: Vehicle, limit: int = 10) -> List[Dict]:
        """Get previously stored matches for a vehicle"""
        
        matches = VehicleMatch.query.filter_by(source_vehicle_id=target_vehicle.id)\
                                   .order_by(VehicleMatch.similarity_score.desc())\
                                   .limit(limit).all()
        
        result = []
        for match in matches:
            result.append({
                'match_id': match.id,
                'vehicle': match.match_vehicle.to_dict(),
                'similarity_score': match.similarity_score,
                'exact_match': match.exact_match,
                'year_match': match.year_match,
                'make_match': match.make_match,
                'model_match': match.model_match,
                'trim_match': match.trim_match,
                'condition_match': match.condition_match,
                'created_at': match.created_at.isoformat(),
                'updated_at': match.updated_at.isoformat()
            })
        
        return result
    
    def find_and_store_matches(self, target_vehicle: Vehicle, **kwargs) -> Dict:
        """
        Find matches for a vehicle and store them in database
        Returns summary of matching results
        """
        
        # Find matches
        matches = self.find_matches(target_vehicle, **kwargs)
        
        # Store matches
        stored_count = self.store_matches(target_vehicle, matches)
        
        return {
            'target_vehicle_id': target_vehicle.id,
            'target_vin': target_vehicle.vin,
            'matches_found': len(matches),
            'matches_stored': stored_count,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def batch_find_matches(self, vehicle_ids: List[int] = None, 
                          batch_size: int = 100, **kwargs) -> Dict:
        """
        Find matches for multiple vehicles in batches
        
        Args:
            vehicle_ids: List of vehicle IDs to process (None for all)
            batch_size: Number of vehicles to process at once
            **kwargs: Arguments passed to find_matches
            
        Returns:
            Summary of batch processing results
        """
        
        logger.info("Starting batch vehicle matching")
        
        # Get vehicles to process
        if vehicle_ids:
            vehicles = Vehicle.query.filter(Vehicle.id.in_(vehicle_ids)).all()
        else:
            vehicles = Vehicle.query.all()
        
        total_vehicles = len(vehicles)
        processed = 0
        total_matches = 0
        errors = 0
        
        logger.info(f"Processing {total_vehicles} vehicles in batches of {batch_size}")
        
        # Process in batches
        for i in range(0, total_vehicles, batch_size):
            batch = vehicles[i:i + batch_size]
            
            for vehicle in batch:
                try:
                    result = self.find_and_store_matches(vehicle, **kwargs)
                    total_matches += result['matches_found']
                    processed += 1
                    
                    if processed % 10 == 0:
                        logger.info(f"Processed {processed}/{total_vehicles} vehicles")
                        
                except Exception as e:
                    logger.error(f"Error processing vehicle {vehicle.vin}: {e}")
                    errors += 1
        
        results = {
            'total_vehicles': total_vehicles,
            'processed': processed,
            'total_matches_found': total_matches,
            'errors': errors,
            'avg_matches_per_vehicle': total_matches / processed if processed > 0 else 0,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        logger.info(f"Batch matching complete: {results}")
        return results

class MarketAnalyzer:
    """Analyze market conditions and competitive positioning"""
    
    def __init__(self):
        self.matching_engine = VehicleMatchingEngine()
    
    def analyze_vehicle_market_position(self, target_vehicle: Vehicle) -> Dict:
        """
        Analyze a vehicle's position in the market
        Returns market analysis with pricing insights
        """
        
        # Get matches for the vehicle
        matches = self.matching_engine.find_matches(
            target_vehicle, 
            min_similarity=0.5, 
            max_matches=20,
            exclude_same_dealer=True
        )
        
        if not matches:
            return {
                'vehicle_id': target_vehicle.id,
                'vin': target_vehicle.vin,
                'market_position': 'insufficient_data',
                'message': 'Not enough comparable vehicles found in market'
            }
        
        # Extract prices from matches
        match_prices = []
        for match in matches:
            if match['vehicle'].price:
                match_prices.append({
                    'price': match['vehicle'].price,
                    'similarity': match['similarity_score'],
                    'vehicle': match['vehicle']
                })
        
        if not match_prices:
            return {
                'vehicle_id': target_vehicle.id,
                'vin': target_vehicle.vin,
                'market_position': 'no_pricing_data',
                'message': 'No pricing data available for comparable vehicles'
            }
        
        # Calculate market statistics
        prices = [mp['price'] for mp in match_prices]
        target_price = target_vehicle.price
        
        market_stats = {
            'min_price': min(prices),
            'max_price': max(prices),
            'avg_price': np.mean(prices),
            'median_price': np.median(prices),
            'std_price': np.std(prices),
            'sample_size': len(prices)
        }
        
        # Determine market position
        if target_price:
            if target_price < market_stats['min_price']:
                position = 'underpriced'
                percentile = 0
            elif target_price > market_stats['max_price']:
                position = 'overpriced'
                percentile = 100
            else:
                # Calculate percentile
                percentile = (sum(1 for p in prices if p <= target_price) / len(prices)) * 100
                
                if percentile <= 25:
                    position = 'underpriced'
                elif percentile >= 75:
                    position = 'overpriced'
                else:
                    position = 'competitive'
        else:
            position = 'no_price'
            percentile = None
        
        return {
            'vehicle_id': target_vehicle.id,
            'vin': target_vehicle.vin,
            'target_price': target_price,
            'market_position': position,
            'percentile_rank': percentile,
            'market_stats': market_stats,
            'comparable_vehicles': len(matches),
            'priced_comparables': len(match_prices),
            'analysis_timestamp': datetime.utcnow().isoformat()
        }

