"""
API routes for pricing scoring and analytics
"""

from flask import Blueprint, request, jsonify
from src.services.scoring import ScoringService, PricingScoreCalculator
from src.models.vehicle import db, Vehicle, VehicleScore
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

scoring_bp = Blueprint('scoring', __name__)

# Initialize services
scoring_service = ScoringService()
score_calculator = PricingScoreCalculator()

@scoring_bp.route('/calculate-score/<vin>', methods=['POST'])
def calculate_score(vin):
    """
    Calculate pricing score for a specific vehicle by VIN
    """
    try:
        # Get the target vehicle
        vehicle = Vehicle.query.filter_by(vin=vin.upper()).first()
        
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        
        # Calculate and store score
        score_data = scoring_service.calculate_and_store_score(vehicle)
        
        return jsonify({
            'success': True,
            'vehicle': vehicle.to_dict(),
            'score_analysis': score_data
        }), 200
    
    except Exception as e:
        logger.error(f"Error calculating score for VIN {vin}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/score/<vin>', methods=['GET'])
def get_score(vin):
    """
    Get stored pricing score for a vehicle by VIN
    """
    try:
        # Get the target vehicle
        vehicle = Vehicle.query.filter_by(vin=vin.upper()).first()
        
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        
        # Get stored score
        score_data = scoring_service.get_vehicle_score(vehicle)
        
        if not score_data:
            return jsonify({
                'success': False,
                'message': 'No score calculated for this vehicle. Use POST /calculate-score/{vin} first.'
            }), 404
        
        return jsonify({
            'success': True,
            'vehicle': vehicle.to_dict(),
            'score': score_data
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting score for VIN {vin}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/batch-calculate', methods=['POST'])
def batch_calculate():
    """
    Calculate scores for multiple vehicles in batch
    """
    try:
        data = request.get_json() or {}
        
        # Get parameters
        vehicle_ids = data.get('vehicle_ids')  # None for all vehicles
        batch_size = data.get('batch_size', 50)
        
        # Run batch calculation
        result = scoring_service.batch_calculate_scores(
            vehicle_ids=vehicle_ids,
            batch_size=batch_size
        )
        
        return jsonify({
            'success': True,
            'result': result
        }), 200
    
    except Exception as e:
        logger.error(f"Error in batch score calculation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/analytics', methods=['GET'])
def get_analytics():
    """
    Get scoring analytics and statistics
    """
    try:
        analytics = scoring_service.get_scoring_analytics()
        
        return jsonify({
            'success': True,
            'analytics': analytics
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting scoring analytics: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/top-scores', methods=['GET'])
def get_top_scores():
    """
    Get vehicles with highest/lowest scores
    """
    try:
        # Get parameters
        order = request.args.get('order', 'desc')  # 'desc' for highest, 'asc' for lowest
        limit = request.args.get('limit', 10, type=int)
        min_score = request.args.get('min_score', type=float)
        max_score = request.args.get('max_score', type=float)
        
        # Build query
        query = db.session.query(VehicleScore, Vehicle).join(Vehicle)
        
        # Apply filters
        if min_score is not None:
            query = query.filter(VehicleScore.overall_score >= min_score)
        if max_score is not None:
            query = query.filter(VehicleScore.overall_score <= max_score)
        
        # Order and limit
        if order == 'desc':
            query = query.order_by(VehicleScore.overall_score.desc())
        else:
            query = query.order_by(VehicleScore.overall_score.asc())
        
        results = query.limit(limit).all()
        
        # Format results
        vehicles_with_scores = []
        for score, vehicle in results:
            vehicles_with_scores.append({
                'vehicle': vehicle.to_dict(),
                'score': score.to_dict()
            })
        
        return jsonify({
            'success': True,
            'vehicles': vehicles_with_scores,
            'count': len(vehicles_with_scores),
            'order': order,
            'limit': limit
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting top scores: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/recommendations', methods=['GET'])
def get_recommendations():
    """
    Get vehicles grouped by recommended actions
    """
    try:
        # Get parameters
        action = request.args.get('action')  # Filter by specific action
        urgency = request.args.get('urgency')  # Not stored in DB, would need to recalculate
        limit = request.args.get('limit', 50, type=int)
        
        # Build query
        query = db.session.query(VehicleScore, Vehicle).join(Vehicle)
        
        if action:
            query = query.filter(VehicleScore.recommended_action == action)
        
        query = query.order_by(VehicleScore.overall_score.asc())  # Lowest scores first (need attention)
        results = query.limit(limit).all()
        
        # Group by action
        recommendations = {}
        for score, vehicle in results:
            action_key = score.recommended_action or 'unknown'
            
            if action_key not in recommendations:
                recommendations[action_key] = []
            
            recommendations[action_key].append({
                'vehicle': vehicle.to_dict(),
                'score': score.to_dict()
            })
        
        return jsonify({
            'success': True,
            'recommendations': recommendations,
            'total_vehicles': sum(len(vehicles) for vehicles in recommendations.values())
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting recommendations: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/market-comparison', methods=['GET'])
def market_comparison():
    """
    Get market comparison data for analysis
    """
    try:
        # Get parameters
        make = request.args.get('make')
        model = request.args.get('model')
        year = request.args.get('year', type=int)
        
        # Build base query
        query = db.session.query(VehicleScore, Vehicle).join(Vehicle)
        
        # Apply filters
        if make:
            query = query.filter(Vehicle.make.ilike(f'%{make}%'))
        if model:
            query = query.filter(Vehicle.model.ilike(f'%{model}%'))
        if year:
            query = query.filter(Vehicle.year == year)
        
        results = query.all()
        
        if not results:
            return jsonify({
                'success': False,
                'message': 'No vehicles found matching criteria'
            }), 404
        
        # Calculate market statistics
        scores = [score.overall_score for score, vehicle in results]
        prices = [vehicle.price for score, vehicle in results if vehicle.price]
        
        market_stats = {
            'vehicle_count': len(results),
            'score_stats': {
                'min_score': min(scores),
                'max_score': max(scores),
                'avg_score': sum(scores) / len(scores),
                'median_score': sorted(scores)[len(scores) // 2]
            },
            'price_stats': {
                'min_price': min(prices) if prices else None,
                'max_price': max(prices) if prices else None,
                'avg_price': sum(prices) / len(prices) if prices else None,
                'median_price': sorted(prices)[len(prices) // 2] if prices else None
            }
        }
        
        # Get sample vehicles
        sample_vehicles = []
        for score, vehicle in results[:10]:  # Top 10
            sample_vehicles.append({
                'vehicle': vehicle.to_dict(),
                'score': score.to_dict()
            })
        
        return jsonify({
            'success': True,
            'market_stats': market_stats,
            'sample_vehicles': sample_vehicles,
            'filters': {
                'make': make,
                'model': model,
                'year': year
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error in market comparison: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@scoring_bp.route('/test-scoring', methods=['POST'])
def test_scoring():
    """
    Test the scoring system with a sample of vehicles
    """
    try:
        data = request.get_json() or {}
        sample_size = data.get('sample_size', 5)
        
        # Get a sample of vehicles
        vehicles = Vehicle.query.limit(sample_size).all()
        
        if not vehicles:
            return jsonify({'error': 'No vehicles found for testing'}), 404
        
        results = []
        for vehicle in vehicles:
            try:
                # Calculate score
                score_data = score_calculator.calculate_overall_score(vehicle)
                
                results.append({
                    'vehicle': {
                        'vin': vehicle.vin,
                        'year': vehicle.year,
                        'make': vehicle.make,
                        'model': vehicle.model,
                        'price': vehicle.price,
                        'condition': vehicle.condition
                    },
                    'overall_score': score_data['overall_score'],
                    'component_scores': score_data['component_scores'],
                    'market_position': score_data['market_position'],
                    'primary_recommendation': score_data['recommendations']['primary_action']
                })
                
            except Exception as e:
                results.append({
                    'vehicle': {
                        'vin': vehicle.vin,
                        'year': vehicle.year,
                        'make': vehicle.make,
                        'model': vehicle.model,
                        'price': vehicle.price,
                        'condition': vehicle.condition
                    },
                    'error': str(e)
                })
        
        return jsonify({
            'success': True,
            'test_results': results,
            'sample_size': len(results)
        }), 200
    
    except Exception as e:
        logger.error(f"Error in test scoring: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

