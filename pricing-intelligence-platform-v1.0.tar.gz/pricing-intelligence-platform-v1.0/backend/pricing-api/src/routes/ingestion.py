"""
API routes for data ingestion
"""

from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
import os
import tempfile
from src.services.ingestion import InventoryIngestionService
from src.models.vehicle import db, Vehicle, VehicleSnapshot
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

ingestion_bp = Blueprint('ingestion', __name__)

# Configure upload settings
ALLOWED_EXTENSIONS = {'csv'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@ingestion_bp.route('/upload-csv', methods=['POST'])
def upload_csv():
    """
    Upload and process inventory CSV file
    """
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Only CSV files are allowed.'}), 400
        
        # Get optional dealer name
        dealer_name = request.form.get('dealer_name')
        
        # Save file temporarily
        filename = secure_filename(file.filename)
        
        with tempfile.NamedTemporaryFile(mode='wb', suffix='.csv', delete=False) as temp_file:
            file.save(temp_file.name)
            temp_path = temp_file.name
        
        try:
            # Process the CSV
            ingestion_service = InventoryIngestionService()
            results = ingestion_service.process_csv(temp_path, dealer_name)
            
            return jsonify({
                'success': True,
                'message': 'CSV processed successfully',
                'results': results
            }), 200
            
        finally:
            # Clean up temporary file
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    except Exception as e:
        logger.error(f"Error processing CSV upload: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingestion_bp.route('/process-sample', methods=['POST'])
def process_sample():
    """
    Process the sample CSV file for testing
    """
    try:
        # Path to sample CSV
        sample_path = '/home/ubuntu/pricing-intelligence-platform/data/sample_inventory.csv'
        
        if not os.path.exists(sample_path):
            return jsonify({'error': 'Sample CSV file not found'}), 404
        
        # Get optional dealer name
        dealer_name = request.json.get('dealer_name') if request.json else None
        
        # Process the CSV
        ingestion_service = InventoryIngestionService()
        results = ingestion_service.process_csv(sample_path, dealer_name)
        
        return jsonify({
            'success': True,
            'message': 'Sample CSV processed successfully',
            'results': results
        }), 200
    
    except Exception as e:
        logger.error(f"Error processing sample CSV: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingestion_bp.route('/vehicles', methods=['GET'])
def get_vehicles():
    """
    Get list of vehicles with optional filtering
    """
    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 50, type=int), 100)
        
        # Filtering parameters
        make = request.args.get('make')
        model = request.args.get('model')
        year = request.args.get('year', type=int)
        condition = request.args.get('condition')
        dealer = request.args.get('dealer')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        
        # Build query
        query = Vehicle.query
        
        if make:
            query = query.filter(Vehicle.make.ilike(f'%{make}%'))
        if model:
            query = query.filter(Vehicle.model.ilike(f'%{model}%'))
        if year:
            query = query.filter(Vehicle.year == year)
        if condition:
            query = query.filter(Vehicle.condition.ilike(f'%{condition}%'))
        if dealer:
            query = query.filter(Vehicle.dealer_name.ilike(f'%{dealer}%'))
        if min_price:
            query = query.filter(Vehicle.price >= min_price)
        if max_price:
            query = query.filter(Vehicle.price <= max_price)
        
        # Order by most recent
        query = query.order_by(Vehicle.created_at.desc())
        
        # Paginate
        pagination = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        vehicles = [vehicle.to_dict() for vehicle in pagination.items]
        
        return jsonify({
            'success': True,
            'vehicles': vehicles,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_prev': pagination.has_prev,
                'has_next': pagination.has_next
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting vehicles: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingestion_bp.route('/vehicles/<vin>', methods=['GET'])
def get_vehicle(vin):
    """
    Get specific vehicle by VIN
    """
    try:
        vehicle = Vehicle.query.filter_by(vin=vin.upper()).first()
        
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        
        # Get vehicle history
        snapshots = VehicleSnapshot.query.filter_by(vehicle_id=vehicle.id)\
                                        .order_by(VehicleSnapshot.snapshot_date.desc())\
                                        .limit(10).all()
        
        return jsonify({
            'success': True,
            'vehicle': vehicle.to_dict(),
            'history': [snapshot.to_dict() for snapshot in snapshots]
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting vehicle {vin}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingestion_bp.route('/stats', methods=['GET'])
def get_stats():
    """
    Get ingestion statistics
    """
    try:
        # Vehicle counts
        total_vehicles = Vehicle.query.count()
        new_vehicles = Vehicle.query.filter_by(condition='New').count()
        used_vehicles = Vehicle.query.filter_by(condition='Used').count()
        certified_vehicles = Vehicle.query.filter_by(condition='Certified').count()
        
        # Make distribution
        make_stats = db.session.query(
            Vehicle.make, 
            db.func.count(Vehicle.id).label('count')
        ).group_by(Vehicle.make).order_by(db.func.count(Vehicle.id).desc()).limit(10).all()
        
        # Year distribution
        year_stats = db.session.query(
            Vehicle.year, 
            db.func.count(Vehicle.id).label('count')
        ).group_by(Vehicle.year).order_by(Vehicle.year.desc()).limit(10).all()
        
        # Price statistics
        price_stats = db.session.query(
            db.func.min(Vehicle.price).label('min_price'),
            db.func.max(Vehicle.price).label('max_price'),
            db.func.avg(Vehicle.price).label('avg_price'),
            db.func.count(Vehicle.price).label('priced_vehicles')
        ).filter(Vehicle.price.isnot(None)).first()
        
        # Dealer distribution
        dealer_stats = db.session.query(
            Vehicle.dealer_name, 
            db.func.count(Vehicle.id).label('count')
        ).group_by(Vehicle.dealer_name).order_by(db.func.count(Vehicle.id).desc()).limit(10).all()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_vehicles': total_vehicles,
                'condition_breakdown': {
                    'new': new_vehicles,
                    'used': used_vehicles,
                    'certified': certified_vehicles
                },
                'top_makes': [{'make': make, 'count': count} for make, count in make_stats],
                'year_distribution': [{'year': year, 'count': count} for year, count in year_stats],
                'price_stats': {
                    'min_price': float(price_stats.min_price) if price_stats.min_price else None,
                    'max_price': float(price_stats.max_price) if price_stats.max_price else None,
                    'avg_price': float(price_stats.avg_price) if price_stats.avg_price else None,
                    'priced_vehicles': price_stats.priced_vehicles
                },
                'top_dealers': [{'dealer': dealer, 'count': count} for dealer, count in dealer_stats]
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ingestion_bp.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint
    """
    try:
        # Test database connection
        vehicle_count = Vehicle.query.count()
        
        return jsonify({
            'success': True,
            'status': 'healthy',
            'database': 'connected',
            'vehicle_count': vehicle_count
        }), 200
    
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 500

