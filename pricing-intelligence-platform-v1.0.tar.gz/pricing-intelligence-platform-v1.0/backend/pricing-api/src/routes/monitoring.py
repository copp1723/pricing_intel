"""
API routes for system monitoring and health checks
Provides endpoints for monitoring system health, performance, and status
"""

from flask import Blueprint, jsonify, request
from src.services.monitoring import get_monitor
import logging

monitoring_bp = Blueprint('monitoring', __name__)

@monitoring_bp.route('/health', methods=['GET'])
def health_check():
    """Simple health check endpoint"""
    try:
        monitor = get_monitor()
        summary = monitor.get_performance_summary()
        
        return jsonify({
            "status": "healthy",
            "timestamp": monitor.start_time.isoformat(),
            "summary": summary
        }), 200
    except Exception as e:
        logging.error(f"Health check failed: {str(e)}")
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

@monitoring_bp.route('/system-health', methods=['GET'])
def system_health():
    """Comprehensive system health endpoint"""
    try:
        monitor = get_monitor()
        health_data = monitor.get_system_health()
        
        return jsonify({
            "success": True,
            "health": health_data
        }), 200
    except Exception as e:
        logging.error(f"System health check failed: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@monitoring_bp.route('/performance', methods=['GET'])
def performance_metrics():
    """Get performance metrics and KPIs"""
    try:
        monitor = get_monitor()
        summary = monitor.get_performance_summary()
        
        return jsonify({
            "success": True,
            "performance": summary
        }), 200
    except Exception as e:
        logging.error(f"Performance metrics failed: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@monitoring_bp.route('/status', methods=['GET'])
def system_status():
    """Get overall system status"""
    try:
        monitor = get_monitor()
        health = monitor.get_system_health()
        
        # Extract key status indicators
        status_data = {
            "overall_status": health["overall_status"],
            "uptime_seconds": health["uptime_seconds"],
            "services": health["services"],
            "database_status": health["database"]["status"],
            "total_vehicles": health["database"]["total_vehicles"],
            "api_requests": health["api"]["total_requests"],
            "error_rate": health["api"]["error_rate_percent"]
        }
        
        return jsonify({
            "success": True,
            "status": status_data
        }), 200
    except Exception as e:
        logging.error(f"System status check failed: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@monitoring_bp.route('/diagnostics', methods=['GET'])
def run_diagnostics():
    """Run system diagnostics"""
    try:
        monitor = get_monitor()
        health = monitor.get_system_health()
        
        # Perform additional diagnostic checks
        diagnostics = {
            "timestamp": health["timestamp"],
            "overall_health": health["overall_status"],
            "components": {
                "database": {
                    "status": health["database"]["status"],
                    "vehicles": health["database"]["total_vehicles"],
                    "scores": health["database"]["total_scores"],
                    "matches": health["database"]["total_matches"]
                },
                "api": {
                    "requests": health["api"]["total_requests"],
                    "errors": health["api"]["total_errors"],
                    "avg_response_time": health["api"]["avg_response_time_ms"]
                },
                "system": {
                    "cpu": health["system"]["cpu_percent"],
                    "memory": health["system"]["memory_percent"],
                    "disk": health["system"]["disk_percent"]
                }
            },
            "services": health["services"],
            "recommendations": []
        }
        
        # Add recommendations based on metrics
        if health["system"]["cpu_percent"] > 80:
            diagnostics["recommendations"].append("High CPU usage detected - consider scaling resources")
        if health["system"]["memory_percent"] > 80:
            diagnostics["recommendations"].append("High memory usage detected - monitor for memory leaks")
        if health["api"]["error_rate_percent"] > 5:
            diagnostics["recommendations"].append("Elevated error rate detected - review recent errors")
        if health["database"]["total_vehicles"] == 0:
            diagnostics["recommendations"].append("No vehicles in database - run data ingestion")
        
        if not diagnostics["recommendations"]:
            diagnostics["recommendations"].append("System is operating normally")
        
        return jsonify({
            "success": True,
            "diagnostics": diagnostics
        }), 200
    except Exception as e:
        logging.error(f"Diagnostics failed: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# Middleware to track API requests
@monitoring_bp.before_app_request
def track_request():
    """Track API request for monitoring"""
    request.start_time = time.time()

@monitoring_bp.after_app_request
def track_response(response):
    """Track API response for monitoring"""
    try:
        if hasattr(request, 'start_time'):
            response_time = (time.time() - request.start_time) * 1000  # Convert to ms
            success = response.status_code < 400
            
            monitor = get_monitor()
            monitor.record_request(response_time, success)
    except:
        pass  # Don't let monitoring errors affect the response
    
    return response

import time

