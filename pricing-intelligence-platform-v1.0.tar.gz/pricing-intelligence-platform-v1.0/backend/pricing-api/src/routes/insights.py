"""
API routes for AI-powered insights generation
"""

from flask import Blueprint, request, jsonify
from src.services.insights import InsightsGenerator
from src.models.vehicle import Vehicle
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

insights_bp = Blueprint('insights', __name__)

# Initialize service
insights_generator = InsightsGenerator()

@insights_bp.route('/vehicle-insights/<vin>', methods=['GET'])
def get_vehicle_insights(vin):
    """
    Generate comprehensive insights for a specific vehicle by VIN
    """
    try:
        # Get the target vehicle
        vehicle = Vehicle.query.filter_by(vin=vin.upper()).first()
        
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        
        # Get parameters
        include_comparisons = request.args.get('include_comparisons', 'true').lower() == 'true'
        
        # Generate insights
        insights = insights_generator.generate_vehicle_insights(
            vehicle, 
            include_comparisons=include_comparisons
        )
        
        return jsonify({
            'success': True,
            'insights': insights
        }), 200
    
    except Exception as e:
        logger.error(f"Error generating insights for VIN {vin}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@insights_bp.route('/market-insights', methods=['GET'])
def get_market_insights():
    """
    Generate market-level insights across inventory
    """
    try:
        # Get parameters (for future filtering)
        filters = {}
        make = request.args.get('make')
        model = request.args.get('model')
        year = request.args.get('year', type=int)
        
        if make:
            filters['make'] = make
        if model:
            filters['model'] = model
        if year:
            filters['year'] = year
        
        # Generate market insights
        insights = insights_generator.generate_market_insights(filters)
        
        return jsonify({
            'success': True,
            'market_insights': insights,
            'filters_applied': filters
        }), 200
    
    except Exception as e:
        logger.error(f"Error generating market insights: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@insights_bp.route('/batch-insights', methods=['POST'])
def generate_batch_insights():
    """
    Generate insights for multiple vehicles
    """
    try:
        data = request.get_json() or {}
        
        # Get parameters
        vehicle_vins = data.get('vins', [])
        limit = data.get('limit', 10)
        include_comparisons = data.get('include_comparisons', True)
        
        if not vehicle_vins:
            # Get sample vehicles if no VINs provided
            vehicles = Vehicle.query.limit(limit).all()
            vehicle_vins = [v.vin for v in vehicles]
        
        # Generate insights for each vehicle
        batch_insights = []
        for vin in vehicle_vins[:limit]:
            try:
                vehicle = Vehicle.query.filter_by(vin=vin.upper()).first()
                if vehicle:
                    insights = insights_generator.generate_vehicle_insights(
                        vehicle, 
                        include_comparisons=include_comparisons
                    )
                    batch_insights.append(insights)
                else:
                    batch_insights.append({
                        'vin': vin,
                        'error': 'Vehicle not found'
                    })
            except Exception as e:
                batch_insights.append({
                    'vin': vin,
                    'error': str(e)
                })
        
        return jsonify({
            'success': True,
            'batch_insights': batch_insights,
            'total_processed': len(batch_insights)
        }), 200
    
    except Exception as e:
        logger.error(f"Error generating batch insights: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@insights_bp.route('/insights-summary', methods=['GET'])
def get_insights_summary():
    """
    Get summary of insights capabilities and status
    """
    try:
        # Get basic statistics
        total_vehicles = Vehicle.query.count()
        
        summary = {
            'insights_engine': 'operational',
            'total_vehicles': total_vehicles,
            'capabilities': {
                'vehicle_insights': 'Generate comprehensive insights for individual vehicles',
                'market_insights': 'Analyze market trends and competitive landscape',
                'batch_processing': 'Process multiple vehicles simultaneously',
                'ai_recommendations': 'AI-powered pricing and strategy recommendations'
            },
            'features': [
                'Executive summaries',
                'Pricing analysis',
                'Market positioning',
                'Risk assessment',
                'Opportunity identification',
                'Actionable recommendations'
            ],
            'data_sources': [
                'Vehicle scoring data',
                'Market comparison analysis',
                'Historical pricing trends',
                'Competitive intelligence'
            ]
        }
        
        return jsonify({
            'success': True,
            'summary': summary
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting insights summary: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@insights_bp.route('/test-insights', methods=['POST'])
def test_insights():
    """
    Test the insights generation system
    """
    try:
        data = request.get_json() or {}
        sample_size = data.get('sample_size', 3)
        
        # Get sample vehicles
        vehicles = Vehicle.query.limit(sample_size).all()
        
        if not vehicles:
            return jsonify({'error': 'No vehicles found for testing'}), 404
        
        test_results = []
        for vehicle in vehicles:
            try:
                # Generate insights
                insights = insights_generator.generate_vehicle_insights(vehicle)
                
                # Extract key information for test results
                test_results.append({
                    'vehicle': {
                        'vin': vehicle.vin,
                        'year': vehicle.year,
                        'make': vehicle.make,
                        'model': vehicle.model,
                        'price': vehicle.price
                    },
                    'insights_generated': True,
                    'executive_summary': insights['insights']['executive_summary'][:100] + '...',
                    'recommendations_count': len(insights['insights']['recommendations']['primary_actions']),
                    'risk_factors_count': len(insights['insights']['risk_factors']),
                    'opportunities_count': len(insights['insights']['opportunities'])
                })
                
            except Exception as e:
                test_results.append({
                    'vehicle': {
                        'vin': vehicle.vin,
                        'year': vehicle.year,
                        'make': vehicle.make,
                        'model': vehicle.model,
                        'price': vehicle.price
                    },
                    'insights_generated': False,
                    'error': str(e)
                })
        
        return jsonify({
            'success': True,
            'test_results': test_results,
            'sample_size': len(test_results)
        }), 200
    
    except Exception as e:
        logger.error(f"Error testing insights: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

