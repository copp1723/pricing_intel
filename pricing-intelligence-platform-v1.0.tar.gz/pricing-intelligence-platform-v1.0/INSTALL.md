# Quick Installation Guide

## Prerequisites
- Python 3.11+
- Node.js 20+
- pnpm package manager
- 4GB+ RAM recommended

## Installation Steps

1. **Extract the package** (if you haven't already):
   ```bash
   tar -xzf pricing-intelligence-platform-v1.0.tar.gz
   cd pricing-intelligence-platform-v1.0
   ```

2. **Run automated setup**:
   ```bash
   ./scripts/setup.sh
   ```

3. **Deploy the platform**:
   ```bash
   ./scripts/deploy.sh
   ```

4. **Access the platform**:
   - Dashboard: http://localhost:5173
   - API: http://localhost:5001

## Manual Setup (if automated setup fails)

### Backend Setup
```bash
cd backend/pricing-api
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

### Frontend Setup
```bash
cd frontend/pricing-dashboard
pnpm install
pnpm run dev --host
```

## Verification
Run the integration tests to verify everything is working:
```bash
python3.11 tests/integration_tests.py
```

For detailed instructions, see README.md and DEPLOYMENT_GUIDE.md
